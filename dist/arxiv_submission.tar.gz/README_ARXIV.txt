README_ARXIV.txt — Standalone arXiv LaTeX Source Bundle (0TH-2026-014)
Title: Coset-Quotient Compression, Separation-Graph Barriers, and Multi-Kernel Verified Frontiers for Zero-Error Shannon Capacity
Author: Alexander Stephen Donahue (ORCID 0009-0006-8168-9648)
Compile with: pdflatex/xelatex/tectonic main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
Repository: https://github.com/0thernes/zero-error-torus-frontier
